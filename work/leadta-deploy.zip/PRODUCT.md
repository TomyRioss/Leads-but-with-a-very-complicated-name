# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Operators prospecting local businesses who need short, structured lead lists, with separate accounts and private search histories.

## Product Purpose

Leadta turns Google Maps keywords and an administrative area into a fixed-size lead batch, stores the search and results in PocketBase, and exports the batch to CSV.

## Positioning

Search runs are capped across all submitted keywords, and every export keeps the same complete set of columns.

## Operating Context

Each operator registers or signs in with email and password, then selects a country, may narrow it by province and district, enters one or more keywords, chooses a result count, reviews their own saved batches, and downloads a CSV.

## Capabilities and Constraints

- Uses the Apify Actor `k-data-lab/google-maps-scraper` with a per-user, per-location monitor to return new places across repeat searches.
- Country is required. Province and district are optional.
- Every lead includes columns for business name, Google Maps link, address, review count, average rating, phone, email, website, social profiles, category, pain points, and enrichment.
- Missing values remain empty in the table and CSV.
- Apify and PocketBase credentials are server-side environment variables.
- Searches save the sample reviews and place details returned by the normal Apify search. Users can run post-generation pain analysis or lead enrichment on a batch with DeepSeek V4.1 Flash via OpenRouter.
- Pain analysis uses review text persisted by the normal search and may audit the lead's website with OpenRouter web fetch. It does not scrape reviews again or treat a Maps URL as review text. Findings require review or website evidence. Enrichment checks selected public social networks. Neither analysis calls Apify.

## Evidence on Hand

The active Apify Actor is `k-data-lab/google-maps-scraper`, with a monitor scoped to each user's location. No brand assets or sample data were provided.

## Product Principles

- Keep the search inputs explicit and quick to scan.
- Enforce the requested batch maximum across keywords.
- Preserve empty cells and a stable CSV schema.
- Keep credentials out of the browser.
- Never present review topics, ratings, or a Maps URL as review text. If a lead has no saved review text and no verifiable website evidence, return no pain findings and surface the limitation.
- Every lead-enrichment run must execute at least one web search on the selected social networks before saving a result; if no search runs, report an error instead of marking it complete.
- Persist verified social profile URLs with the selected network list; show only those selected networks as separate lead-table columns.
- Keep the shared Ash and Lime brand palette defined in AGENTS.md.
- Never expose another account's batches or leads.

## Backprop

- B1 | 2026-11-07 | OpenRouter server tools were optional and the model completed without searching; usage parsing also read an outdated field. | V1
- B2 | 2026-11-07 | VPS PocketBase lacked the migrations for lead review data, so it silently saved leads without the new JSON fields. | V2
- V1: Every social enrichment request selects at least one network, executes at least one OpenRouter web search, and is not saved as complete when that search did not run.
- V2: Every deployment verifies that PocketBase has the required `users.phone` and lead fields, including `social_profiles`, `source_reviews`, and `source_context`, before treating saved leads as complete.
- B3 | 2026-11-07 | Enrichment returned narrative text without persisting profile URLs per network, while the UI exposed one generic social column. | V3
- V3: Enrichment validates and persists official profile URLs by selected network, then renders only those networks as separate columns.
- B4 | 2026-11-09 | Pain analysis relied on a JSON prompt without response_format, allowing narrative output that the parser could not save. | Mechanical omission corrected by requiring the existing strict schema for all analysis requests.
- B5 | 2026-11-14 | Highlighted lead mentions used semibold glyph widths unlike the transparent textarea, shifting the visible caret. | V4
- V4: Text mirrors over inputs preserve the input's font metrics; highlighting may change color, never glyph width, so caret and selection stay aligned.
- B6 | 2026-11-14 | The WhatsApp worker could return a disconnected session as HTTP 200 after socket startup failed, leaving the connect button with no visible result. | V5
- V5: WhatsApp connection attempts that end disconnected surface an actionable error; brand controls use the WhatsApp logo.
- B7 | 2026-11-14 | A WhatsApp callback retry found its contact log already saved and skipped repairing the lead status after a partial write failure. | V6
- V6: A duplicate successful-send callback repairs a still-uncontacted lead without adding another contact log or downgrading an advanced status.
- B8 | 2026-11-17 | A batch-wide WhatsApp drafting request fell into repeated per-lead fuzzy searches and exhausted the chat tool budget before analyzing pains or drafting messages. | V7
- V7: Batch-wide message requests resolve one batch, analyze it once, draft one card per lead with evidence, and reuse results for identical tool calls; they do not search or analyze leads individually.
- B9 | 2026-11-18 | Completed pain analyses with no findings were treated as incomplete, leaving the per-lead analyze action visible; sequential batch work also stopped starting leads after 130 seconds. | V8
- V8: A completed pain analysis for the current focus is terminal even with no findings and renders “Sin datos” instead of an analyze action; batch analysis uses bounded concurrency and reports any unfinished leads with a retry action.
