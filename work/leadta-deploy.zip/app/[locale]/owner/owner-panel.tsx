"use client";

import { useCallback, useEffect, useRef, useState, type ComponentType } from "react";
import dynamic from "next/dynamic";
import { useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { ArrowLeftRight, ChartLine, CreditCard, LayoutDashboard, Newspaper, LoaderCircle, LogOut, Megaphone, Menu, MessageSquare, Receipt, RefreshCw, Route, ScrollText, Search, Sparkles, Users, X } from "lucide-react";
import { BrandLogo } from "@/app/brand-logo";
import { LanguageSwitcher } from "@/app/language-switcher";
import { Link } from "@/i18n/navigation";
import { ghostButton, iconButton, isUnauthorized, ownerFetch, stateBox, useFocusTrap, type OnAction } from "./ui";
import { getSession, invalidateSession } from "@/lib/client/session";
import StaffChat from "./staff/staff-chat";

export type OwnerSectionKey = "staff" | "resumen" | "analiticas" | "usuarios" | "suscripciones" | "pagos" | "campanas" | "busquedas" | "comentarios" | "blog" | "trazabilidad" | "auditoria";

const navItems: { key: OwnerSectionKey; label: string; icon: ComponentType<{ size?: number; className?: string; "aria-hidden"?: boolean }> }[] = [
  { key: "staff", label: "navStaff", icon: Sparkles },
  { key: "resumen", label: "navSummary", icon: LayoutDashboard },
  { key: "analiticas", label: "navAnalytics", icon: ChartLine },
  { key: "usuarios", label: "navUsers", icon: Users },
  { key: "suscripciones", label: "navSubscriptions", icon: CreditCard },
  { key: "pagos", label: "navPayments", icon: Receipt },
  { key: "campanas", label: "navCampaigns", icon: Megaphone },
  { key: "busquedas", label: "navSearches", icon: Search },
  { key: "comentarios", label: "navFeedback", icon: MessageSquare },
  { key: "blog", label: "navBlog", icon: Newspaper },
  { key: "trazabilidad", label: "navTraceability", icon: Route },
  { key: "auditoria", label: "navAudit", icon: ScrollText },
];

const Loading = () => {
  const t = useTranslations("Owner");
  return <p className={stateBox} role="status"><LoaderCircle className="animate-spin" size={16} aria-hidden="true" /> {t("common.loading")}</p>;
};
// Each section is only loaded (and only requests its data) while it is the active one.
const Overview = dynamic(() => import("./sections/overview-section"), { loading: Loading });
const AnalyticsSection = dynamic(() => import("./sections/analytics-section"), { loading: Loading });
const UsersSection = dynamic(() => import("./sections/users-section"), { loading: Loading });
const SubscriptionsSection = dynamic(() => import("./sections/subscriptions-section"), { loading: Loading });
const PaymentsSection = dynamic(() => import("./sections/payments-section"), { loading: Loading });
const CampaignsSection = dynamic(() => import("./sections/campaigns-section"), { loading: Loading });
const SearchesSection = dynamic(() => import("./sections/searches-section"), { loading: Loading });
const FeedbackSection = dynamic(() => import("./sections/feedback-section"), { loading: Loading });
const BlogSection = dynamic(() => import("./sections/blog-section"), { loading: Loading });
const TraceabilitySection = dynamic(() => import("./sections/traceability-section"), { loading: Loading });
const AuditSection = dynamic(() => import("./sections/audit-section"), { loading: Loading });

const sectionKeys = navItems.map((item) => item.key);

export default function OwnerPanel() {
  const t = useTranslations("Owner");
  const requested = useSearchParams().get("s");
  const initialSection = sectionKeys.find((key) => key === requested) ?? "resumen";
  const [auth, setAuth] = useState<"loading" | "owner" | "error">("loading");
  const [attempt, setAttempt] = useState(0);
  const [section, setSection] = useState<OwnerSectionKey>(initialSection);
  // Leadtita Staff mounts on first visit and then stays mounted (hidden) so its conversation survives navigation.
  const [staffMounted, setStaffMounted] = useState(initialSection === "staff");
  const [email, setEmail] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState<{ id: number; text: string } | null>(null);
  const router = useRouter();
  const sidebarRef = useRef<HTMLElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const mainRef = useRef<HTMLElement>(null);

  // Without an owner session there is nothing to show here: send the user back to the app.
  const leavePanel = useCallback(() => router.replace("/buscar"), [router]);

  useEffect(() => {
    let active = true;
    ownerFetch("/api/owner/me").then((result) => {
      if (!active) return;
      if (result.ok) setAuth("owner");
      else if (isUnauthorized(result.status)) leavePanel();
      else setAuth("error");
    });
    return () => { active = false; };
  }, [attempt, leavePanel]);

  useEffect(() => {
    if (auth !== "owner") return;
    let active = true;
    getSession().then((result) => {
      if (active && result.ok) setEmail(result.user?.email ?? "");
    }, () => undefined);
    return () => { active = false; };
  }, [auth]);

  const closeMenu = useCallback(() => {
    setMenuOpen(false);
    menuButtonRef.current?.focus();
  }, []);
  useFocusTrap(sidebarRef, menuOpen, closeMenu);
  useEffect(() => {
    if (menuOpen) sidebarRef.current?.querySelector<HTMLElement>("a, button")?.focus();
  }, [menuOpen]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 10_000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function go(next: OwnerSectionKey) {
    setMenuOpen(false);
    setSection(next);
    if (next === "staff") setStaffMounted(true);
    router.replace(`/owner?s=${next}`, { scroll: false });
    window.scrollTo(0, 0);
    mainRef.current?.focus({ preventScroll: true });
  }

  const onAction: OnAction = useCallback((text) => setToast({ id: Date.now(), text }), []);

  function retry() {
    setAuth("loading");
    setAttempt((value) => value + 1);
  }

  async function logout() {
    await ownerFetch("/api/auth/logout", { method: "POST" });
    invalidateSession();
    leavePanel();
  }

  const sidebarOpen = menuOpen ? "max-md:visible max-md:translate-x-0" : "max-md:invisible max-md:-translate-x-full";
  const current = navItems.find((item) => item.key === section) ?? navItems[0];
  const staffActive = auth === "owner" && section === "staff";

  return (
    <div className={`min-h-dvh bg-(--ash-100) text-(color:--ink) md:grid md:grid-cols-[224px_minmax(0,1fr)] ${staffActive ? "max-md:flex max-md:h-dvh max-md:flex-col" : ""}`}>
      <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-(color:--line) bg-(--paper) px-4 py-3 md:hidden">
        <button ref={menuButtonRef} className={iconButton} type="button" onClick={() => setMenuOpen(true)} aria-label={t("shell.openMenu")} aria-expanded={menuOpen} aria-controls="owner-sidebar"><Menu size={18} aria-hidden="true" /></button>
        <span className="text-sm font-semibold">{t(`shell.${current.label}`)}</span>
        <LanguageSwitcher />
        <span className="ml-auto rounded-full bg-(--ash-950) px-2 py-[3px] text-[10px] font-bold uppercase tracking-wider text-(color:--lime)">{t("shell.badge")}</span>
      </header>

      {menuOpen && <div className="fixed inset-0 z-40 bg-(--ash-950)/45 md:hidden" onMouseDown={closeMenu} aria-hidden="true" />}

      <aside
        id="owner-sidebar"
        ref={sidebarRef}
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col gap-4 border-r border-(color:--line) bg-(--paper) p-4 transition-transform md:sticky md:top-0 md:z-auto md:h-dvh md:w-auto md:translate-x-0 md:visible ${sidebarOpen}`}
        aria-label={t("shell.panelLabel")}
      >
        <div className="grid gap-3 border-b border-(color:--line) pb-4">
          <div className="flex min-h-10 items-center justify-between gap-3">
            <BrandLogo />
            <span className="rounded-full bg-(--ash-950) px-2.5 py-1 text-[10px] font-bold uppercase leading-none tracking-wider text-(color:--lime)">{t("shell.badge")}</span>
            <button className={`${iconButton} md:hidden`} type="button" onClick={closeMenu} aria-label={t("shell.closeMenu")}><X size={18} aria-hidden="true" /></button>
          </div>
          <div className="flex"><LanguageSwitcher /></div>
          {/* Owners are also users: one click to the customer app (and back via "Panel owner" in its sidebar). */}
          <Link className={`${ghostButton} w-full justify-start no-underline`} href="/leadtita">
            <ArrowLeftRight size={15} aria-hidden="true" /> {t("shell.userPanel")}
          </Link>
        </div>

        <nav aria-label={t("shell.sectionsLabel")} className="grid gap-1">
          {navItems.map(({ key, label, icon: Icon }) => {
            const active = key === section;
            const featured = key === "staff";
            return (
              <button
                key={key}
                type="button"
                aria-current={active ? "page" : undefined}
                onClick={() => go(key)}
                className={`flex min-h-11 w-full cursor-pointer items-center gap-3 rounded-lg px-3 text-left text-[13px]! font-semibold! focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-(color:--ash-950) ${featured ? "mb-2 border border-(color:--lime-dark) pl-2" : "border-0"} ${active ? "bg-(--lime) text-(color:--ash-950)! hover:bg-(--lime-dark)" : featured ? "bg-(--lime)/20 text-(color:--ink)! hover:bg-(--lime)/40" : "bg-transparent text-(color:--ash-800)! hover:bg-(--ash-100)"}`}
              >
                {/* Leadtita Staff goes first and featured, like Leadtita in the customer sidebar (lime icon chip). */}
                {featured
                  ? <span className={`inline-grid size-[26px] shrink-0 place-items-center rounded-[7px] ${active ? "bg-(--ash-950) text-(color:--lime)" : "bg-(--lime) text-(color:--ash-950) shadow-[inset_0_0_0_1px_var(--lime-dark)]"}`} aria-hidden="true"><Icon size={15} aria-hidden={true} /></span>
                  : <Icon className="shrink-0" size={16} aria-hidden={true} />}
                <span className="truncate">{t(`shell.${label}`)}</span>
              </button>
            );
          })}
        </nav>

        <div className="mt-auto grid gap-2 border-t border-(color:--line) pt-3">
          {email && <p className="m-0 break-all text-[11px] text-(color:--muted)" title={email}>{email}</p>}
          <button className={ghostButton} type="button" onClick={() => void logout()}><LogOut size={15} aria-hidden="true" /> {t("shell.signOut")}</button>
        </div>
      </aside>

      <main ref={mainRef} tabIndex={-1} className={`min-w-0 outline-none ${staffActive ? "max-md:flex max-md:min-h-0 max-md:flex-1 max-md:flex-col" : ""}`}>
        {/* Full-height chat page; hidden (not unmounted) on other sections so the conversation survives. */}
        {auth === "owner" && staffMounted && <StaffChat hidden={section !== "staff"} />}
        {!staffActive && <div className="mx-auto w-[calc(100%-32px)] max-w-[1680px] pb-20 pt-5 md:pt-8">
          {/* Shell visible from the first paint; sections mount only once owner access is confirmed. */}
          {auth === "loading" && <p className={stateBox} role="status"><LoaderCircle className="animate-spin" size={16} aria-hidden="true" /> {t("common.loading")}</p>}
          {auth === "error" && (
            <div className={`${stateBox} flex-wrap justify-center`} role="alert">
              <span>{t("shell.sessionError")}</span>
              <button className={ghostButton} type="button" onClick={retry}><RefreshCw size={15} aria-hidden="true" /> {t("shell.retry")}</button>
            </div>
          )}
          {auth === "owner" && <>
          {section === "resumen" && <Overview onUnauthorized={leavePanel} onOpenAudit={() => go("auditoria")} />}
          {section === "analiticas" && <AnalyticsSection onUnauthorized={leavePanel} />}
          {section === "usuarios" && <UsersSection onUnauthorized={leavePanel} onAction={onAction} />}
          {section === "suscripciones" && <SubscriptionsSection onUnauthorized={leavePanel} onAction={onAction} />}
          {section === "pagos" && <PaymentsSection onUnauthorized={leavePanel} />}
          {section === "campanas" && <CampaignsSection onUnauthorized={leavePanel} onAction={onAction} />}
          {section === "busquedas" && <SearchesSection onUnauthorized={leavePanel} onAction={onAction} />}
          {section === "comentarios" && <FeedbackSection onUnauthorized={leavePanel} onAction={onAction} />}
          {section === "blog" && <BlogSection onUnauthorized={leavePanel} onAction={onAction} />}
          {section === "trazabilidad" && <TraceabilitySection onUnauthorized={leavePanel} />}
          {section === "auditoria" && <AuditSection onUnauthorized={leavePanel} />}
          </>}
        </div>}
      </main>

      <div className="pointer-events-none fixed inset-x-4 bottom-4 z-60 flex justify-end" aria-live="polite">
        {toast && (
          <div className="pointer-events-auto flex max-w-md items-center gap-3 rounded-[10px] border border-(color:--ash-950) bg-(--paper) px-4 py-3 text-xs shadow-lg" role="status">
            <span className="font-semibold">{toast.text}</span>
            {section !== "auditoria" && <button className="cursor-pointer whitespace-nowrap rounded border-0 bg-transparent p-1 text-xs font-semibold underline underline-offset-[3px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-(color:--ash-950)" type="button" onClick={() => { setToast(null); go("auditoria"); }}>{t("shell.viewInAudit")}</button>}
            <button className="cursor-pointer rounded border-0 bg-transparent p-1 text-(color:--muted) focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-(color:--ash-950)" type="button" onClick={() => setToast(null)} aria-label={t("shell.dismissNotice")}><X size={14} aria-hidden="true" /></button>
          </div>
        )}
      </div>
    </div>
  );
}
