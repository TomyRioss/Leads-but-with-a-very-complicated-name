import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Geist } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import { hasLocale, NextIntlClientProvider } from "next-intl";
import { getMessages, getTranslations, setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { routing } from "@/i18n/routing";
import { CampaignBanner } from "@/app/campaign-banner";
import "react-phone-number-input/style.css";
import "../globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) return {};
  const t = await getTranslations({ locale, namespace: "Meta" });
  return {
    metadataBase: new URL(process.env.APP_URL?.trim() || "https://leadta.app"),
    title: t("title"),
    description: t("description"),
    applicationName: "Leadta",
    openGraph: { type: "website", siteName: "Leadta", locale: locale === "es" ? "es_AR" : "en_US", title: t("title"), description: t("description") },
    twitter: { card: "summary", title: t("title"), description: t("description") },
  };
}

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

export default async function RootLayout({ children, params }: { children: ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) notFound();
  setRequestLocale(locale);
  const messages = await getMessages({ locale });

  return (
    <html
      lang={locale}
      translate="no"
      className={`${geistSans.variable} notranslate h-full antialiased`}
    >
      <head>
        {/* Native locales own the UI text; browser translation can break React updates. */}
        <meta name="google" content="notranslate" />
      </head>
      <body className="min-h-full flex flex-col">
        <NextIntlClientProvider
          locale={locale}
          messages={messages}
          formats={{}}
          now={new Date("2026-01-01T00:00:00.000Z")}
          timeZone="UTC"
        >
          <CampaignBanner />
          {children}
        </NextIntlClientProvider>
        <Analytics />
      </body>
    </html>
  );
}
