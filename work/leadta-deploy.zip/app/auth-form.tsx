"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { FormEvent } from "react";
import { useLocale, useTranslations } from "next-intl";
import { Check, Circle, CircleCheck, KeyRound, LoaderCircle, Mail, TriangleAlert } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { isValidPhoneNumber } from "libphonenumber-js/min";
import PhoneInput from "react-phone-number-input";
import es from "react-phone-number-input/locale/es.json";
import en from "react-phone-number-input/locale/en.json";
import { BrandMark } from "./brand-logo";
import { TurnstileField, type TurnstileFieldHandle } from "./turnstile-field";
import { Link } from "@/i18n/navigation";
import "./auth-steps.css";
import "./auth-layout.css";
import { invalidateSession } from "@/lib/client/session";

/** `paths`: switching login/register also swaps the URL (no reload). */
type AuthFormProps = { onAuthenticated: () => void; initialMode?: "login" | "register"; paths?: Record<"login" | "register", string> };
type VerifyStepState = { email: string; sent: boolean; fromLogin: boolean };

const resendCooldownSeconds = 60;
const emailPattern = /^\S+@\S+\.\S+$/;

type ResendStatus = "idle" | "sending" | "sent" | "error";

/** POSTs `{ email, locale }` to `endpoint` (verification or password-reset link) with a resend cooldown. */
function useResendVerification(email: string, initialCooldown = 0, endpoint = "/api/auth/verification") {
  const locale = useLocale();
  const [status, setStatus] = useState<ResendStatus>("idle");
  const [remaining, setRemaining] = useState(initialCooldown);

  useEffect(() => {
    if (remaining <= 0) return;
    const timer = setTimeout(() => setRemaining((seconds) => seconds - 1), 1000);
    return () => clearTimeout(timer);
  }, [remaining]);

  async function resend() {
    if (status === "sending" || remaining > 0) return;
    setStatus("sending");
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, locale }),
      });
      if (!response.ok) throw new Error("resend failed");
      setStatus("sent");
      setRemaining(resendCooldownSeconds);
    } catch {
      setStatus("error");
    }
  }

  return { status, remaining, resend };
}

function ResendAction({ resend, type = "button", disabled = false }: { resend: ReturnType<typeof useResendVerification>; type?: "button" | "submit"; disabled?: boolean }) {
  const t = useTranslations("Verification");
  const sending = resend.status === "sending";
  return (
    <>
      <button
        className="primary-button auth-submit"
        type={type}
        onClick={type === "button" ? resend.resend : undefined}
        disabled={sending || resend.remaining > 0 || disabled}
      >
        {sending && <LoaderCircle className="auth-spin" size={16} aria-hidden="true" />}
        {sending ? t("resending") : resend.remaining > 0 ? t("resendIn", { seconds: resend.remaining }) : t("resend")}
      </button>
      <p className="auth-feedback" role="status" data-tone={resend.status === "error" ? "error" : undefined}>
        {resend.status === "sent" ? t("resendSuccess") : resend.status === "error" ? t("resendFailed") : ""}
      </p>
    </>
  );
}

function VerifyStep({ state, onChangeEmail, onLogin }: { state: VerifyStepState; onChangeEmail: () => void; onLogin: () => void }) {
  const t = useTranslations("Verification");
  const headingRef = useRef<HTMLHeadingElement>(null);
  const resend = useResendVerification(state.email, state.sent ? resendCooldownSeconds : 0);

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  return (
    <>
      <span className="auth-verify-icon" aria-hidden="true"><Mail size={22} /></span>
      <h1 id="auth-title" ref={headingRef} tabIndex={-1}>{t("verifyTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
      <p className="auth-intro">
        {t.rich(state.fromLogin ? "verifyIntroLogin" : state.sent ? "verifyIntro" : "verifyIntroNotSent", { email: state.email, strong: (chunks) => <strong className="auth-verify-email">{chunks}</strong> })}
      </p>
      {(state.sent || resend.status === "sent") && <p className="auth-verify-hint">{t("verifyHint")}</p>}
      <div className="auth-verify-actions">
        <ResendAction resend={resend} />
        <button className="auth-secondary-button" type="button" onClick={onChangeEmail}>{t("changeEmail")}</button>
      </div>
      <p className="auth-switch">
        {t("alreadyVerified")}{" "}
        <button type="button" onClick={onLogin}>{t("startSession")}</button>
      </p>
    </>
  );
}

function PhoneStep({ onDone }: { onDone: (role?: string) => void }) {
  const t = useTranslations("Auth");
  const locale = useLocale();
  const [phone, setPhone] = useState("");
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const invalid = !phone || !isValidPhoneNumber(phone);

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (invalid) {
      setTouched(true);
      setError(t("validPhone"));
      document.getElementById("phone")?.focus();
      return;
    }
    setBusy(true);
    try {
      invalidateSession();
      const response = await fetch("/api/auth/phone", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, locale }),
      });
      invalidateSession(); // new cookie: never reuse the previous session
      const payload = await response.json();
      if (response.status === 401) throw new Error(t("googlePhoneExpired"));
      if (response.status === 409) throw new Error(t("phoneTaken"));
      if (!response.ok) throw new Error(response.status === 400 ? t("validPhone") : t("serviceUnavailable"));
      onDone(payload.user?.role);
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : t("connectionFailed"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <h1 id="auth-title" ref={headingRef} tabIndex={-1}>{t("googlePhoneTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
      <p className="auth-intro">{t("googlePhoneIntro")}</p>
      <form className="auth-fields" onSubmit={save}>
        <div className="field">
          <label className="field-label" htmlFor="phone">{t("phone")}<span className="required-mark" aria-hidden="true"> *</span></label>
          <PhoneInput
            id="phone"
            defaultCountry="AR"
            labels={locale === "es" ? es : en}
            value={phone}
            onChange={(value) => setPhone(value || "")}
            onBlur={() => setTouched(true)}
            autoComplete="tel"
            aria-describedby={touched && invalid ? "phone-error" : "phone-help"}
            numberInputProps={{ id: "phone", required: true, "aria-label": t("phoneAria"), "aria-invalid": touched && Boolean(phone) && invalid }}
            international
          />
          <span className="field-help" id="phone-help">{t("phoneHelp")}</span>
          {touched && invalid && <span className="field-help auth-inline-error" id="phone-error" role="status">{t("phoneInvalid")}</span>}
        </div>
        {error && <p className="auth-error" role="alert">{error}</p>}
        <button className="primary-button auth-submit" type="submit" disabled={busy}>
          {busy ? t("connecting") : t("googlePhoneSubmit")}
        </button>
      </form>
    </>
  );
}

type VerifyResult = "verified" | "invalid" | "failed";
type PanelState = "ready" | "loading" | VerifyResult;

export function VerifyEmailPanel({ token, locale, initialResult }: { token: string; locale: string; initialResult?: VerifyResult }) {
  const t = useTranslations("Verification");
  const [state, setState] = useState<PanelState>(initialResult ?? (token ? "ready" : "invalid"));
  const [email, setEmail] = useState("");
  const resend = useResendVerification(email.trim().toLowerCase());

  async function confirm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("loading");
    try {
      invalidateSession();
      const response = await fetch("/api/auth/verify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, locale }),
      });
      invalidateSession(); // new cookie: never reuse the previous session
      const payload = (await response.json()) as { result?: VerifyResult };
      setState(payload.result === "verified" || payload.result === "invalid" ? payload.result : "failed");
    } catch {
      setState("failed");
    }
  }

  function requestNewLink(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void resend.resend();
  }

  if (state === "loading") {
    return (
      <div role="status" aria-live="polite">
        <span className="auth-verify-icon" aria-hidden="true"><LoaderCircle className="auth-spin" size={22} /></span>
        <h1 id="verify-email-title">{t("loading")}</h1>
      </div>
    );
  }

  if (state === "verified") {
    return (
      <div role="status" aria-live="polite">
        <span className="auth-verify-icon" aria-hidden="true"><CircleCheck size={22} /></span>
        <h1 id="verify-email-title">{t("verifiedTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
        <p className="auth-intro">{t("verifiedDescription")}</p>
        <div className="auth-verify-actions">
          <Link className="primary-button auth-submit" href="/buscar">{t("continue")}</Link>
        </div>
      </div>
    );
  }

  if (state === "failed") {
    return (
      <>
        <span className="auth-verify-icon" data-tone="error" aria-hidden="true"><TriangleAlert size={22} /></span>
        <h1 id="verify-email-title">{t("failedTitle")}</h1>
        <p className="auth-intro" role="alert">{t("failed")}</p>
        <div className="auth-verify-actions">
          {token && <button className="primary-button auth-submit" type="button" onClick={() => setState("ready")}>{t("retry")}</button>}
          <Link className="auth-secondary-button" href="/buscar">{t("backToLeadta")}</Link>
        </div>
        <p className="field-help verification-footnote">{t("privacy")}</p>
      </>
    );
  }

  if (state === "invalid") {
    return (
      <>
        <span className="auth-verify-icon" data-tone="error" aria-hidden="true"><TriangleAlert size={22} /></span>
        <h1 id="verify-email-title">{t("invalidTitle")}</h1>
        <p className="auth-intro">{t("invalid")}</p>
        <form className="auth-fields" onSubmit={requestNewLink}>
          <label className="field">
            <span className="field-label">{t("email")}<span className="required-mark" aria-hidden="true"> *</span></span>
            <input type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={254} />
          </label>
          <div className="auth-verify-actions">
            <ResendAction resend={resend} type="submit" disabled={!emailPattern.test(email.trim())} />
          </div>
        </form>
        <p className="field-help verification-footnote">{t("privacy")}</p>
      </>
    );
  }

  return (
    <>
      <h1 id="verify-email-title">{t("title")}<span className="brand-dot" aria-hidden="true">.</span></h1>
      <p className="auth-intro">{t("description")}</p>
      <form className="auth-fields" action="/api/auth/verify-email" method="post" onSubmit={confirm}>
        <input type="hidden" name="token" value={token} />
        <input type="hidden" name="locale" value={locale} />
        <button className="primary-button auth-submit" type="submit">{t("button")}</button>
      </form>
      <p className="field-help verification-footnote">{t("privacy")}</p>
    </>
  );
}

function ForgotPasswordStep({ initialEmail, onBack }: { initialEmail: string; onBack: () => void }) {
  const t = useTranslations("Auth");
  const [email, setEmail] = useState(initialEmail);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const request = useResendVerification(email.trim().toLowerCase(), 0, "/api/auth/password-reset");
  const sending = request.status === "sending";

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void request.resend();
  }

  return (
    <>
      <span className="auth-verify-icon" aria-hidden="true"><KeyRound size={22} /></span>
      <h1 id="auth-title" ref={headingRef} tabIndex={-1}>{t("forgotTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
      <p className="auth-intro">{t("forgotIntro")}</p>
      <form className="auth-fields" onSubmit={submit}>
        <label className="field">
          <span className="field-label">{t("email")}<span className="required-mark" aria-hidden="true"> *</span></span>
          <input type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={254} />
        </label>
        <button className="primary-button auth-submit" type="submit" disabled={sending || request.remaining > 0 || !emailPattern.test(email.trim())}>
          {sending && <LoaderCircle className="auth-spin" size={16} aria-hidden="true" />}
          {sending ? t("forgotSending") : request.remaining > 0 ? t("forgotResendIn", { seconds: request.remaining }) : request.status === "sent" ? t("forgotResend") : t("forgotSubmit")}
        </button>
        <p className="auth-feedback" role="status" data-tone={request.status === "error" ? "error" : undefined}>
          {request.status === "sent" ? t("forgotSent") : request.status === "error" ? t("forgotFailed") : ""}
        </p>
      </form>
      <p className="auth-switch">
        {t("forgotRemembered")}{" "}
        <button type="button" onClick={onBack}>{t("startSession")}</button>
      </p>
    </>
  );
}

type ResetState = "ready" | "saving" | "reset" | "invalid";

/** /restablecer: new password from the emailed link. */
export function ResetPasswordPanel({ token, locale }: { token: string; locale: string }) {
  const t = useTranslations("Auth");
  const [state, setState] = useState<ResetState>(token ? "ready" : "invalid");
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const mismatch = Boolean(passwordConfirm && password !== passwordConfirm);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (password.length < 6) {
      setError(t("passwordLength"));
      document.getElementById("password")?.focus();
      return;
    }
    if (password !== passwordConfirm) {
      setError(t("passwordMismatch"));
      document.getElementById("password-confirm")?.focus();
      return;
    }
    setState("saving");
    try {
      const response = await fetch("/api/auth/password-reset/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password, passwordConfirm, locale }),
      });
      const payload = (await response.json()) as { result?: string; error?: string };
      if (payload.result === "reset" || payload.result === "invalid") {
        setState(payload.result);
        return;
      }
      setError(payload.error || t("resetFailed"));
    } catch {
      setError(t("resetFailed"));
    }
    setState("ready");
  }

  if (state === "reset") {
    return (
      <div role="status" aria-live="polite">
        <span className="auth-verify-icon" aria-hidden="true"><CircleCheck size={22} /></span>
        <h1 id="reset-password-title">{t("resetDoneTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
        <p className="auth-intro">{t("resetDone")}</p>
        <div className="auth-verify-actions">
          <Link className="primary-button auth-submit" href="/login">{t("goToLogin")}</Link>
        </div>
      </div>
    );
  }

  if (state === "invalid") {
    return (
      <>
        <span className="auth-verify-icon" data-tone="error" aria-hidden="true"><TriangleAlert size={22} /></span>
        <h1 id="reset-password-title">{t("resetInvalidTitle")}</h1>
        <p className="auth-intro">{t("resetInvalid")}</p>
        <div className="auth-verify-actions">
          <Link className="primary-button auth-submit" href="/login">{t("goToLogin")}</Link>
        </div>
      </>
    );
  }

  return (
    <>
      <h1 id="reset-password-title">{t("resetTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
      <p className="auth-intro">{t("resetIntro")}</p>
      <form className="auth-fields" onSubmit={submit}>
        <label className="field">
          <span className="field-label">{t("newPassword")}<span className="required-mark" aria-hidden="true"> *</span></span>
          <span className="password-control">
            <input id="password" type={showPassword ? "text" : "password"} autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={6} maxLength={128} aria-describedby="password-help" />
            <button className="password-toggle" type="button" aria-label={showPassword ? t("hidePassword") : t("showPassword")} aria-pressed={showPassword} onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? t("hidePassword") : t("showPassword")}
            </button>
          </span>
          <span className="field-help password-requirements" id="password-help" aria-live="polite">
            <span className={password.length >= 6 ? "requirement met" : "requirement"}>{password.length >= 6 ? <Check size={14} aria-hidden="true" /> : <Circle size={14} aria-hidden="true" />}{t("minimumPassword")}</span>
            <span className={passwordConfirm && password === passwordConfirm ? "requirement met" : "requirement"}>{passwordConfirm && password === passwordConfirm ? <Check size={14} aria-hidden="true" /> : <Circle size={14} aria-hidden="true" />}{t("confirmMatch")}</span>
          </span>
        </label>
        <label className="field">
          <span className="field-label">{t("confirmPassword")}<span className="required-mark" aria-hidden="true"> *</span></span>
          <input id="password-confirm" type={showPassword ? "text" : "password"} autoComplete="new-password" value={passwordConfirm} onChange={(event) => setPasswordConfirm(event.target.value)} required maxLength={128} aria-invalid={mismatch} aria-describedby={mismatch ? "password-confirm-error" : undefined} />
          {mismatch && <span className="field-help auth-inline-error" id="password-confirm-error" role="status">{t("passwordMismatch")}</span>}
        </label>
        {error && <p className="auth-error" role="alert">{error}</p>}
        <button className="primary-button auth-submit" type="submit" disabled={state === "saving"}>
          {state === "saving" && <LoaderCircle className="auth-spin" size={16} aria-hidden="true" />}
          {state === "saving" ? t("resetSaving") : t("resetSubmit")}
        </button>
      </form>
    </>
  );
}

// Email que deja el popup de registro de la landing (app/landing/signup-popup.tsx). Se lee y borra una vez;
// el valor queda en memoria para que el doble render de StrictMode reciba lo mismo.
let signupEmail: string | null = null;
function takeSignupEmail() {
  if (signupEmail === null) {
    try {
      signupEmail = sessionStorage.getItem("leadta:signup-email") ?? "";
      sessionStorage.removeItem("leadta:signup-email");
    } catch {
      signupEmail = "";
    }
  }
  return signupEmail;
}

const noSubscribe = () => () => {};
/** Query param read without a hydration mismatch: null on the server and during hydration, then the real value. */
function useQueryParam(name: string) {
  return useSyncExternalStore(noSubscribe, () => new URLSearchParams(window.location.search).get(name), () => null);
}

export function AuthForm({ onAuthenticated, initialMode = "login", paths }: AuthFormProps) {
  const t = useTranslations("Auth");
  const locale = useLocale();
  const localizedError = (message: string) => {
    if (locale !== "en") return message;
    const messages: Record<string, string> = {
      "No se pudo conectar con el servicio de cuentas.": t("serviceUnavailable"),
      "Email o contraseña incorrectos.": t("invalidCredentials"),
      "Ingresá un email y una contraseña válidos.": t("validEmailPassword"),
      "Ingresá un email válido.": t("validEmail"),
      "Ingresá los datos requeridos para crear la cuenta.": t("validRequired"),
      "No se pudo crear la cuenta. Revisá si el email ya está registrado.": t("accountExists"),
      "Ingresá un número de teléfono válido.": t("validPhone"),
      "La contraseña debe tener al menos 6 caracteres.": t("passwordLength"),
      "Las contraseñas no coinciden.": t("passwordMismatch"),
      "Ese teléfono ya está registrado.": t("phoneTaken"),
      "La contraseña debe tener entre 6 y 128 caracteres.": t("passwordRange"),
    };
    return messages[message] ?? message;
  };
  const [mode, setMode] = useState<"login" | "register">(initialMode);
  const [email, setEmail] = useState(() => (initialMode === "register" ? takeSignupEmail() : ""));
  const [phone, setPhone] = useState("");
  const [phoneTouched, setPhoneTouched] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordConfirm, setShowPasswordConfirm] = useState(false);
  const [error, setError] = useState("");
  const [verifyStep, setVerifyStep] = useState<VerifyStepState | null>(null);
  const [forgotStep, setForgotStep] = useState(false);
  const [busy, setBusy] = useState(false);
  // Google's callback lands here with ?authStep=phone or ?authError=google. Read as an external store: null while prerendering.
  const phoneStep = useQueryParam("authStep") === "phone";
  const googleFailed = useQueryParam("authError") === "google";
  const [googleErrorCleared, setGoogleErrorCleared] = useState(false);
  const shownError = error || (googleFailed && !googleErrorCleared ? t("googleLoginFailed") : "");
  const clearError = () => {
    setError("");
    setGoogleErrorCleared(true);
  };
  const captchaRef = useRef<TurnstileFieldHandle>(null);
  // `?next=` return path (e.g. the MCP consent page), read on mount: switching login/register drops the query.
  // The Google route validates it server-side.
  const nextPath = useRef<string | null>(null);
  useEffect(() => { nextPath.current = new URLSearchParams(window.location.search).get("next"); }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    clearError();
    const captcha = new FormData(event.currentTarget).get("cf-turnstile-response");

    if (mode === "register") {
      if (!phone || !isValidPhoneNumber(phone)) {
        setPhoneTouched(true);
        setError(t("validPhone"));
        document.getElementById("phone")?.focus();
        return;
      }
      if (password.length < 6) {
        setError(t("passwordLength"));
        document.getElementById("password")?.focus();
        return;
      }
      if (password !== passwordConfirm) {
        setError(t("passwordMismatch"));
        document.getElementById("password-confirm")?.focus();
        return;
      }
    }

    if (typeof captcha !== "string" || !captcha) {
      setError(t("captchaRequired"));
      return;
    }

    setBusy(true);
    try {
      invalidateSession();
      const response = await fetch(`/api/auth/${mode === "register" ? "register" : "login"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mode === "register" ? { email, phone, password, passwordConfirm, locale, captcha } : { email, password, captcha }),
      });
      invalidateSession(); // new cookie: never reuse the previous session
      const payload = await response.json();
      if (payload.code === "EMAIL_NOT_VERIFIED") {
        setVerifyStep({ email: email.trim().toLowerCase(), sent: false, fromLogin: true });
        return;
      }
      if (!response.ok) throw new Error(payload.error || t("loginFailed"));
      if (payload.verificationRequired) {
        setVerifyStep({ email: email.trim().toLowerCase(), sent: Boolean(payload.verificationSent), fromLogin: false });
        return;
      }
      // A return path (validated by AuthPage) wins over the owner panel, so owners can finish e.g. the MCP consent.
      if (payload.user?.role === "owner" && !nextPath.current) {
        window.location.assign(window.location.pathname.startsWith("/en/") ? "/en/owner" : "/owner");
        return;
      }
      onAuthenticated();
    } catch (submitError) {
      setError(localizedError(submitError instanceof Error ? submitError.message : t("connectionFailed")));
      captchaRef.current?.reset(); // Turnstile tokens are single-use
    } finally {
      setBusy(false);
    }
  }

  function changeMode(nextMode: "login" | "register") {
    setMode(nextMode);
    if (!paths) return;
    window.history.replaceState(null, "", paths[nextMode]);
    document.title = t(nextMode === "register" ? "registerTitle" : "loginTitle");
  }

  function switchMode() {
    clearError();
    changeMode(mode === "register" ? "login" : "register");
  }

  function backToForm(nextMode: "login" | "register") {
    setVerifyStep(null);
    setForgotStep(false);
    clearError();
    changeMode(nextMode);
    requestAnimationFrame(() => document.getElementById("auth-title")?.focus());
  }

  return (
    <main className="app-shell auth-shell auth-bare">
      <aside className="auth-aside">
        <Link className="auth-brand-link" href="/" aria-label={t("goHome")}><BrandMark className="auth-brand-mark" /></Link>
        <div className="auth-aside-copy">
          <p className="auth-aside-eyebrow">{t("asideEyebrow")}</p>
          <p className="auth-aside-title">{t("asideTitle")}</p>
          <p className="auth-aside-text">{t("asideText")}</p>
        </div>
      </aside>
      <div className="auth-workspace">
        <section className="search-panel auth-panel" aria-labelledby="auth-title">
          {phoneStep ? (
            <PhoneStep onDone={(role) => {
              if (role === "owner") window.location.assign(window.location.pathname.startsWith("/en/") ? "/en/owner" : "/owner");
              else {
                window.history.replaceState(null, "", window.location.pathname);
                onAuthenticated();
              }
            }} />
          ) : verifyStep ? (
            <VerifyStep state={verifyStep} onChangeEmail={() => backToForm(mode)} onLogin={() => backToForm("login")} />
          ) : forgotStep ? (
            <ForgotPasswordStep initialEmail={email} onBack={() => backToForm("login")} />
          ) : (
          <>
          <h1 id="auth-title" tabIndex={-1}>{mode === "register" ? t("registerTitle") : t("loginTitle")}<span className="brand-dot" aria-hidden="true">.</span></h1>
          <p className="auth-intro">{mode === "register" && t("registerIntro")}{t("privateIntro")}</p>
          <a className="google-auth-button" href={`/api/auth/google?locale=${locale}`} onClick={(event) => {
            // The default navigation then follows the updated href.
            if (nextPath.current) event.currentTarget.href = `/api/auth/google?locale=${locale}&next=${encodeURIComponent(nextPath.current)}`;
          }}><FcGoogle size={18} aria-hidden="true" /><span>{t("continueWithGoogle")}</span></a>
          <div className="auth-divider" aria-hidden="true"><span>{t("orContinueWithEmail")}</span></div>
          <form className="auth-fields" onSubmit={submit}>
            <label className="field">
              <span className="field-label">{t("email")}<span className="required-mark" aria-hidden="true"> *</span></span>
              <input type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={254} />
            </label>
            {mode === "register" && (
              <div className="field">
                <label className="field-label" htmlFor="phone">{t("phone")}<span className="required-mark" aria-hidden="true"> *</span></label>
                <PhoneInput
                  id="phone"
                  defaultCountry="AR"
                  labels={locale === "es" ? es : en}
                  value={phone}
                  onChange={(value) => setPhone(value || "")}
                  onBlur={() => setPhoneTouched(true)}
                  autoComplete="tel"
                  aria-invalid={phoneTouched && Boolean(phone) && !isValidPhoneNumber(phone)}
                  aria-describedby={phoneTouched && !isValidPhoneNumber(phone) ? "phone-error" : "phone-help"}
                  numberInputProps={{ id: "phone", required: true, "aria-label": t("phoneAria"), "aria-invalid": phoneTouched && Boolean(phone) && !isValidPhoneNumber(phone) }}
                  international
                />
                <span className="field-help" id="phone-help">{t("phoneHelp")}</span>
                {phoneTouched && !isValidPhoneNumber(phone) && <span className="field-help auth-inline-error" id="phone-error" role="status">{t("phoneInvalid")}</span>}
              </div>
            )}
            <label className="field">
              <span className="field-label">{t("password")}<span className="required-mark" aria-hidden="true"> *</span></span>
              <span className="password-control">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete={mode === "register" ? "new-password" : "current-password"}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  required
                  minLength={mode === "register" ? 6 : 1}
                  maxLength={128}
                  aria-describedby={mode === "register" ? "password-help" : undefined}
                />
                <button className="password-toggle" type="button" aria-label={showPassword ? t("hidePassword") : t("showPassword")} aria-pressed={showPassword} onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? t("hidePassword") : t("showPassword")}
                </button>
              </span>
              {mode === "register" && (
                <span className="field-help password-requirements" id="password-help" aria-live="polite">
                  <span className={password.length >= 6 ? "requirement met" : "requirement"}>{password.length >= 6 ? <Check size={14} aria-hidden="true" /> : <Circle size={14} aria-hidden="true" />}{t("minimumPassword")}</span>
                  <span className={passwordConfirm && password === passwordConfirm ? "requirement met" : "requirement"}>{passwordConfirm && password === passwordConfirm ? <Check size={14} aria-hidden="true" /> : <Circle size={14} aria-hidden="true" />}{t("confirmMatch")}</span>
                </span>
              )}
            </label>
            {mode === "login" && (
              <p className="auth-forgot">
                <button className="auth-switch-link" type="button" onClick={() => { clearError(); setForgotStep(true); }}>{t("forgotLink")}</button>
              </p>
            )}
            {mode === "register" && (
              <label className="field">
                <span className="field-label">{t("confirmPassword")}<span className="required-mark" aria-hidden="true"> *</span></span>
                <span className="password-control">
                  <input
                    id="password-confirm"
                    type={showPasswordConfirm ? "text" : "password"}
                    autoComplete="new-password"
                    value={passwordConfirm}
                    onChange={(event) => setPasswordConfirm(event.target.value)}
                    required
                    maxLength={128}
                    aria-invalid={Boolean(passwordConfirm && password !== passwordConfirm)}
                    aria-describedby={passwordConfirm && password !== passwordConfirm ? "password-confirm-error" : undefined}
                  />
                  <button className="password-toggle" type="button" aria-label={showPasswordConfirm ? t("hideConfirm") : t("showConfirm")} aria-pressed={showPasswordConfirm} onClick={() => setShowPasswordConfirm(!showPasswordConfirm)}>
                    {showPasswordConfirm ? t("hidePassword") : t("showPassword")}
                  </button>
                </span>
                {passwordConfirm && password !== passwordConfirm && <span className="field-help auth-inline-error" id="password-confirm-error" role="status">{t("passwordMismatch")}</span>}
              </label>
            )}
            <TurnstileField ref={captchaRef} locale={locale} />
            {shownError && <p className="auth-error" role="alert">{shownError}</p>}
            <button className="primary-button auth-submit" type="submit" disabled={busy}>
              {busy ? t("connecting") : mode === "register" ? t("createAccount") : t("signIn")}
            </button>
          </form>
          <p className="auth-switch">
            {mode === "register" ? t("alreadyAccount") : t("firstTime")}{" "}
            <button type="button" onClick={switchMode}>
              {mode === "register" ? t("startSession") : t("createAccount")}
            </button>
          </p>
          </>
          )}
        </section>
      </div>
    </main>
  );
}
